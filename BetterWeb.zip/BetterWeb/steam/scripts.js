let buildVersion = "dev";

let disableRainbow = buildVersion === "dev" || buildVersion === "stable";

let threadComments = document.getElementsByClassName("commentthread_comment_text");
if (!disableRainbow) {
    for (let comment of threadComments) {
        // Loop through every letter and if it is surrounded by asterisks, make it rainbow
        let commentText = comment.innerHTML;
        commentText = commentText.replace(/\*(.*?)\*/g, "<span class='rainbow'>$1</span>");
    }
}